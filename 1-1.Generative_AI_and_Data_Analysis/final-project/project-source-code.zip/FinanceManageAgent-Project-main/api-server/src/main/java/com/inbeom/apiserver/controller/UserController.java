package com.inbeom.apiserver.controller;

import com.inbeom.apiserver.dto.common.ApiResponse;
import com.inbeom.apiserver.dto.user.*;
import com.inbeom.apiserver.service.UserService;
import com.inbeom.apiserver.util.JwtTokenProvider;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;
    private final JwtTokenProvider jwtTokenProvider;

    /**
     * GET /api/users/me
     * Get user profile
     */
    @GetMapping("/me")
    public ResponseEntity<ApiResponse<UserProfileResponse>> getUserProfile(
            @RequestHeader("Authorization") String authHeader
    ) {
        String token = authHeader.substring(7);
            Long userId = jwtTokenProvider.getUserIdFromToken(token);

        UserProfileResponse profile = userService.getUserProfile(userId);

        return ResponseEntity.ok(
                ApiResponse.success("User profile retrieved successfully", profile)
        );
    }

    /**
     * PUT /api/users/me
     * Update user profile
     */
    @PutMapping("/me")
    public ResponseEntity<ApiResponse<UserProfileResponse>> updateUserProfile(
            @RequestHeader("Authorization") String authHeader,
            @Valid @RequestBody UpdateUserProfileRequest request
    ) {
        String token = authHeader.substring(7);
        Long userId = jwtTokenProvider.getUserIdFromToken(token);

        UserProfileResponse profile = userService.updateUserProfile(userId, request);

        return ResponseEntity.ok(
                ApiResponse.success("User profile updated successfully", profile)
        );
    }

    /**
     * GET /api/users/settings
     * Get user settings
     */
    @GetMapping("/settings")
    public ResponseEntity<ApiResponse<UserSettingsResponse>> getUserSettings(
            @RequestHeader("Authorization") String authHeader
    ) {
        String token = authHeader.substring(7);
        Long userId = jwtTokenProvider.getUserIdFromToken(token);

        UserSettingsResponse settings = userService.getUserSettings(userId);

        return ResponseEntity.ok(
                ApiResponse.success("User settings retrieved successfully", settings)
        );
    }

    /**
     * PUT /api/users/settings
     * Update user settings
     */
    @PutMapping("/settings")
    public ResponseEntity<ApiResponse<UserSettingsResponse>> updateUserSettings(
            @RequestHeader("Authorization") String authHeader,
            @Valid @RequestBody UpdateUserSettingsRequest request
    ) {
        String token = authHeader.substring(7);
        Long userId = jwtTokenProvider.getUserIdFromToken(token);

        UserSettingsResponse settings = userService.updateUserSettings(userId, request);

        return ResponseEntity.ok(
                ApiResponse.success("User settings updated successfully", settings)
        );
    }

    /**
     * DELETE /api/users/me
     * Delete user account (회원 탈퇴)
     */
    @DeleteMapping("/me")
    public ResponseEntity<ApiResponse<Void>> deleteAccount(
            @RequestHeader("Authorization") String authHeader
    ) {
        String token = authHeader.substring(7);
        Long userId = jwtTokenProvider.getUserIdFromToken(token);

        log.info("User deletion requested: userId={}", userId);
        userService.deleteAccount(userId);

        return ResponseEntity.ok(
                ApiResponse.success("Account deleted successfully", null)
        );
    }

    /**
     * GET /api/users/kis-account
     * Get user KIS account information
     */
    @GetMapping("/kis-account")
    public ResponseEntity<ApiResponse<KisAccountResponse>> getKisAccount(
            @RequestHeader("Authorization") String authHeader
    ) {
        String token = authHeader.substring(7);
        Long userId = jwtTokenProvider.getUserIdFromToken(token);

        KisAccountResponse kisAccount = userService.getKisAccount(userId);

        return ResponseEntity.ok(
                ApiResponse.success("KIS account retrieved successfully", kisAccount)
        );
    }

    /**
     * PUT /api/users/kis-account
     * Update user KIS account information
     */
    @PutMapping("/kis-account")
    public ResponseEntity<ApiResponse<KisAccountResponse>> updateKisAccount(
            @RequestHeader("Authorization") String authHeader,
            @Valid @RequestBody UpdateKisAccountRequest request
    ) {
        String token = authHeader.substring(7);
        Long userId = jwtTokenProvider.getUserIdFromToken(token);

        KisAccountResponse kisAccount = userService.updateKisAccount(userId, request);

        return ResponseEntity.ok(
                ApiResponse.success("KIS account updated successfully", kisAccount)
        );
    }

    /**
     * GET /api/users/trade-config
     * Get user trade configuration
     */
    @GetMapping("/trade-config")
    public ResponseEntity<ApiResponse<TradeConfigResponse>> getTradeConfig(
            @RequestHeader("Authorization") String authHeader
    ) {
        String token = authHeader.substring(7);
        Long userId = jwtTokenProvider.getUserIdFromToken(token);

        TradeConfigResponse config = userService.getTradeConfig(userId);

        return ResponseEntity.ok(
                ApiResponse.success("Trade configuration retrieved successfully", config)
        );
    }

    /**
     * PUT /api/users/trade-config
     * Update user trade configuration
     */
    @PutMapping("/trade-config")
    public ResponseEntity<ApiResponse<TradeConfigResponse>> updateTradeConfig(
            @RequestHeader("Authorization") String authHeader,
            @Valid @RequestBody UpdateTradeConfigRequest request
    ) {
        String token = authHeader.substring(7);
        Long userId = jwtTokenProvider.getUserIdFromToken(token);

        TradeConfigResponse config = userService.updateTradeConfig(userId, request);

        return ResponseEntity.ok(
                ApiResponse.success("Trade configuration updated successfully", config)
        );
    }
}
