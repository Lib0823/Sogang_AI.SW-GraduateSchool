package com.inbeom.apiserver.controller;

import com.inbeom.apiserver.dto.common.ApiResponse;
import com.inbeom.apiserver.dto.market.*;
import com.inbeom.apiserver.service.MarketAnalysisService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@Slf4j
@RestController
@RequestMapping("/market")
@RequiredArgsConstructor
public class MarketAnalysisController {

    private final MarketAnalysisService marketAnalysisService;

    /**
     * 시장 전체 요약 데이터 조회
     * GET /api/market/summary?date=2025-05-27
     */
    @GetMapping("/summary")
    public ResponseEntity<ApiResponse<MarketSummaryResponse>> getMarketSummary(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date
    ) {
        log.info("GET /api/market/summary - date: {}", date);

        LocalDate targetDate = marketAnalysisService.resolveDate(date);
        MarketSummaryResponse response = marketAnalysisService.getMarketSummary(targetDate);

        return ResponseEntity.ok(ApiResponse.success(response));
    }

    /**
     * 시장 감성 분석 데이터 조회
     * GET /api/market/sentiment?date=2025-05-27
     */
    @GetMapping("/sentiment")
    public ResponseEntity<ApiResponse<MarketSentimentResponse>> getMarketSentiment(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date
    ) {
        log.info("GET /api/market/sentiment - date: {}", date);

        LocalDate targetDate = marketAnalysisService.resolveDate(date);
        MarketSentimentResponse response = marketAnalysisService.getMarketSentiment(targetDate);

        return ResponseEntity.ok(ApiResponse.success(response));
    }

    /**
     * AI 매매 결정 TOP3 조회
     * GET /api/market/decisions?date=2025-05-27
     */
    @GetMapping("/decisions")
    public ResponseEntity<ApiResponse<MarketDecisionsResponse>> getMarketDecisions(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date
    ) {
        log.info("GET /api/market/decisions - date: {}", date);

        LocalDate targetDate = marketAnalysisService.resolveDate(date);
        MarketDecisionsResponse response = marketAnalysisService.getMarketDecisions(targetDate);

        return ResponseEntity.ok(ApiResponse.success(response));
    }

    /**
     * 최신 분석 날짜 조회
     * GET /api/market/latest-date
     */
    @GetMapping("/latest-date")
    public ResponseEntity<ApiResponse<LatestDateResponse>> getLatestAnalysisDate() {
        log.info("GET /api/market/latest-date");

        LatestDateResponse response = marketAnalysisService.getLatestAnalysisDate();

        return ResponseEntity.ok(ApiResponse.success(response));
    }

    /**
     * 30종목 히트맵 데이터 조회
     * GET /api/market/heatmap?date=2025-05-27
     */
    @GetMapping("/heatmap")
    public ResponseEntity<ApiResponse<MarketHeatmapResponse>> getHeatmapData(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date
    ) {
        log.info("GET /api/market/heatmap - date: {}", date);

        LocalDate targetDate = marketAnalysisService.resolveDate(date);
        MarketHeatmapResponse response = marketAnalysisService.getHeatmapData(targetDate);

        return ResponseEntity.ok(ApiResponse.success(response));
    }

    /**
     * 단일 종목 AI 분석 요약 조회 (Bot 화면 보유 종목 카드용)
     * GET /api/market/stock-analysis/{stockCode}?date=2025-05-27
     */
    @GetMapping("/stock-analysis/{stockCode}")
    public ResponseEntity<ApiResponse<StockAnalysisResponse>> getStockAnalysis(
            @PathVariable String stockCode,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date
    ) {
        log.info("GET /api/market/stock-analysis/{} - date: {}", stockCode, date);

        // date 가 null 이면 서비스가 종목별 최신 분석일로 fallback 처리 (resolveDate 사용 안 함)
        StockAnalysisResponse response = marketAnalysisService.getStockAnalysis(stockCode, date);

        return ResponseEntity.ok(ApiResponse.success(response));
    }

    /**
     * 단일 종목 AI 분석 상세 조회 (종목 상세 화면 AI 분석 탭용)
     * GET /api/market/stock-detail/{stockCode}?date=2025-05-27
     */
    @GetMapping("/stock-detail/{stockCode}")
    public ResponseEntity<ApiResponse<StockDetailAnalysisResponse>> getStockDetailAnalysis(
            @PathVariable String stockCode,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date
    ) {
        log.info("GET /api/market/stock-detail/{} - date: {}", stockCode, date);

        // date 가 null 이면 서비스가 종목별 최신 분석일로 fallback 처리 (resolveDate 사용 안 함)
        StockDetailAnalysisResponse response = marketAnalysisService.getStockDetailAnalysis(stockCode, date);

        return ResponseEntity.ok(ApiResponse.success(response));
    }
}
